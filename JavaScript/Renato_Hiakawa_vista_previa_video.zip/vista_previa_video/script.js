function playVideo(video) {
    video.play();
}

function pauseVideo(video) {
    video.pause();
}